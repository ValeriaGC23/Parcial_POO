import accidentes.*;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Date;

public class Main {

    static void lanzarMenu() {
        System.out.println("------Ingrese la opción--------");
        System.out.println("1. Agregar Carro");
        System.out.println("2. Agregar Dueño");
        System.out.println("3. Agregar Incidente");
        System.out.println("4. Agregar Comentario");
        System.out.println("5. Agregar Marca");
        System.out.println("6. Mostrar la marca más vendida");
        System.out.println("7. Mostrar la marca de carros con más incidentes");
        System.out.println("8. Mostrar el país de origen más común y cuantos carros tiene");
        System.out.println("9. Mostrar los incidentes de cada dueño");
        System.out.println("10.Salir");
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Scanner scint = new Scanner(System.in);

        ArrayList<Carro> carros = new ArrayList<>();
        ArrayList<Dueno> duenos = new ArrayList<>();
        ArrayList<Incidente> incidentes = new ArrayList<>();
        ArrayList<Comentario> comentarios = new ArrayList<>();
        ArrayList<Marca> marcas = new ArrayList<>();

        Carro c1 = new Carro("JKL458", "Mazda 3", 2021);
        carros.add(c1);
        Carro c2 = new Carro("FTR892", "Renault Sandero", 2019);
        carros.add(c2);
        Carro c3 = new Carro("MNP305", "Toyota Corolla", 2020);
        carros.add(c3);
        Carro c4 = new Carro("QRS777", "Kia Picanto", 2018);
        carros.add(c4);
        Carro c5 = new Carro("VXY654", "Chevrolet Onix", 2022);
        carros.add(c5);
        Carro c6 = new Carro("ZBC910", "Nissan Frontier", 2017);
        carros.add(c6);
        Carro c7 = new Carro("ZWT870", "Mazda 2", 2015);
        carros.add(c7);

        Dueno d1 = new Dueno(1001234567L, "Carlos", "Ramírez", "3004567890");
        duenos.add(d1);
        Dueno d2 = new Dueno(1012345678L, "María", "González", "3109876543");
        duenos.add(d2);
        Dueno d3 = new Dueno(1023456789L, "Andrés", "Martínez", "3151239876");
        duenos.add(d3);
        Dueno d4 = new Dueno(1034567890L, "Laura", "Pérez", "3014567891");
        duenos.add(d4);
        Dueno d5 = new Dueno(1045678901L, "Jorge", "López", "3126549870");
        duenos.add(d5);
        Dueno d6 = new Dueno(1056789012L, "Valentina", "Castro", "3201112233");
        duenos.add(d6);

        Incidente i1 = new Incidente(5001L, "Choque leve", new Date(2024, 4, 12), "3004567890");
        incidentes.add(i1);
        Incidente i2 = new Incidente(5002L, "Exceso de velocidad", new Date(2022, 10, 25), "3109876543");
        incidentes.add(i2);
        Incidente i3 = new Incidente(5003L, "Conducción en estado de embriaguez", new Date(2025, 7, 3), "3151239876");
        incidentes.add(i3);
        Incidente i4 = new Incidente(5004L, "Accidente grave", new Date(2020, 1, 18), "3014567891");
        incidentes.add(i4);
        Incidente i5 = new Incidente(5005L, "Paso de semáforo en rojo", new Date(2025, 2, 9), "3126549870");
        incidentes.add(i5);
        Incidente i6 = new Incidente(5006L, "Daños a propiedad", new Date(2022, 11, 30), "3201112233");
        incidentes.add(i6);

        Marca m1 = new Marca(1L, "Mazda", "Japón");
        marcas.add(m1);
        Marca m2 = new Marca(2L, "Renault", "Francia");
        marcas.add(m2);
        Marca m3 = new Marca(3L, "Chevrolet", "Estados Unidos");
        marcas.add(m3);
        Marca m4 = new Marca(4L, "Kia", "Corea del Sur");
        marcas.add(m4);
        Marca m5 = new Marca(5L, "Toyota", "Japón");
        marcas.add(m5);
        Marca m6 = new Marca(6L, "Nissan", "Japón");
        marcas.add(m6);

        d1.vincularCarro(c1);
        d2.vincularCarro(c2);
        d3.vincularCarro(c3);
        d3.vincularCarro(c4);
        d4.vincularCarro(c5);
        d5.vincularCarro(c6);
        d6.vincularCarro(c7);

        c1.vincularDueno(d1);
        c2.vincularDueno(d2);
        c3.vincularDueno(d3);
        c4.vincularDueno(d3);
        c5.vincularDueno(d4);
        c6.vincularDueno(d5);
        c7.vincularDueno(d6);

        c3.agregarComentario("El choque no dejó heridos", i3.getFechaIncidente());
        c1.agregarComentario("Pintura rayada en la puerta", i1.getFechaIncidente());
        c4.agregarComentario("El chasis quedó torcido", i4.getFechaIncidente());
        c5.agregarComentario("Bumper dañado", i5.getFechaIncidente());
        c5.agregarComentario("Fallo de frenos", i5.getFechaIncidente());
        c2.agregarComentario("No afecto al carro", i2.getFechaIncidente());

        c1.setMarca(m1);
        c2.setMarca(m2);
        c3.setMarca(m5);
        c4.setMarca(m4);
        c5.setMarca(m3);
        c6.setMarca(m6);
        c7.setMarca(m1);

        m1.agregarCarro(c1);
        m2.agregarCarro(c2);
        m3.agregarCarro(c5);
        m4.agregarCarro(c4);
        m5.agregarCarro(c3);
        m6.agregarCarro(c6);
        m1.agregarCarro(c7);

        d1.agregarIncidente(i1);
        d2.agregarIncidente(i2);
        d2.agregarIncidente(i3);
        d4.agregarIncidente(i4);
        d4.agregarIncidente(i5);
        d6.agregarIncidente(i6);

        i1.setDueno(d1);
        i2.setDueno(d2);
        i3.setDueno(d2);
        i4.setDueno(d4);
        i5.setDueno(d4);
        i6.setDueno(d6);

        boolean salir = false;
        int opcion = 0;

        System.out.println("**********Bienvenido**********");
        lanzarMenu();
        opcion = scint.nextInt();


        while (!salir) {
            switch (opcion) {
                case 1:
                    System.out.println("Ingrese la placa del auto: ");
                    String placa = sc.nextLine();
                    System.out.println("Ingrese el modelo: ");
                    String modelo = sc.nextLine();
                    System.out.println("Ingrese el año de lanzamiento: ");
                    int anioLanzamiento = scint.nextInt();

                    Carro c = new Carro(placa, modelo, anioLanzamiento);
                    carros.add(c);

                    System.out.println("Carro registrado.");
                    lanzarMenu();
                    opcion = scint.nextInt();
                    break;



                case 2:
                    System.out.println("Ingrese su cédula: ");
                    long cedula = scint.nextLong();
                    System.out.println("Ingrese su nombre: ");
                    String nombre = sc.nextLine();
                    System.out.println("Ingrese sus apellidos: ");
                    String apellido = sc.nextLine();
                    System.out.println("Ingrese su telefono: ");
                    String telefono = sc.nextLine();

                    Dueno d = new Dueno(cedula, nombre, apellido, telefono);
                    duenos.add(d);

                    System.out.println("Dueño registrado.");
                    lanzarMenu();
                    opcion = scint.nextInt();
                    break;


                case 3:
                    System.out.println("Ingrese el código del incidente: ");
                    long codigo = scint.nextLong();
                    System.out.println("Ingrese el tipo de incidente: ");
                    String tipoIncidente = sc.nextLine();
                    System.out.println("Ingrese la fecha del incidente (dd/MM/yyyy): ");
                    Date fechaIncidente = new Date();
                    System.out.println("Ingrese su telefono: ");
                    String telefonoI = sc.nextLine();

                    Incidente i = new Incidente(codigo, tipoIncidente, fechaIncidente, telefonoI);
                    incidentes.add(i);

                    System.out.println("Incidente registrado.");
                    lanzarMenu();
                    opcion = scint.nextInt();
                    break;


                case 4:
                    System.out.println("Ingrese el id del comentario ");
                    long id = scint.nextLong();
                    System.out.println("Ingrese la descripción del comentario: ");
                    String descripcion = sc.nextLine();
                    System.out.println("Ingrese la fecha del comentario: ");
                    Date fechaComentario = new Date();

                    Comentario com = new Comentario();
                    com.setId(id);
                    com.setDescripcion(descripcion);
                    com.setFechaComentario(fechaComentario);
                    comentarios.add(com);

                    System.out.println("Comentario añadido.");
                    lanzarMenu();
                    opcion = scint.nextInt();
                    break;


                case 5:
                    System.out.print("Ingrese el id de la marca: ");
                    long idM = sc.nextLong();
                    System.out.print("Ingrese el nombre de la marca: ");
                    String nombreM = sc.nextLine();
                    System.out.print("Ingrese el pais de la marca: ");
                    String pais = sc.nextLine();

                    Marca m = new Marca(idM, nombreM, pais);
                    marcas.add(m);

                    System.out.println("Marca registrada.");
                    lanzarMenu();
                    opcion = scint.nextInt();
                    break;


                case 6:
                    if (carros.isEmpty()) {
                        System.out.println("No hay carros registrados.");
                        lanzarMenu();
                        opcion = scint.nextInt();
                        break;
                    }
                    String marcaMasVendida = "";
                    int maxMarca = 0;
                    for (Marca x : marcas) {
                        int contador = 0;
                        for (Carro z : carros) {
                            if (z.getMarca() != null && z.getMarca().getNombre().equals(x.getNombre())) {
                                contador++;
                            }
                        }
                        if (contador > maxMarca) {
                            maxMarca = contador;
                            marcaMasVendida = x.getNombre();
                        }
                    }
                    System.out.println("La marca mas vendida es: " + marcaMasVendida + " con " + maxMarca + " carros.");
                    lanzarMenu();
                    opcion = scint.nextInt();
                    break;


                case 7:
                    if (incidentes.isEmpty()) {
                        System.out.println("No hay incidentes registrados.");
                        lanzarMenu();
                        opcion = scint.nextInt();
                        break;
                    }

                    String marcaMasIncidentes = "";
                    int maxI = 0;

                    for (Marca z : marcas) {
                        int contador = 0;
                        for (Incidente x : incidentes) {
                            for (Dueno y : duenos) {
                                for (Carro w : y.getCarros()) {
                                    if (w.getMarca() != null && w.getMarca().getNombre().equals(z.getNombre())) {
                                        contador++;
                                        break;
                                    }
                                }
                            }
                        }
                        if (contador > maxI) {
                            maxI = contador;
                            marcaMasIncidentes = z.getNombre();
                        }
                    }

                    System.out.println("La marca con mas incidentes es: " + marcaMasIncidentes + " con " + maxI + " incidentes.");
                    lanzarMenu();
                    opcion = scint.nextInt();
                    break;


                case 8:
                    if (marcas.isEmpty()) {
                        System.out.println("No hay marcas registradas.");
                        lanzarMenu();
                        opcion = scint.nextInt();
                        break;
                    }
                    String paisMasComun = "";
                    int maxP = 0;
                    for (Marca x : marcas) {
                        int contador = 0;
                        for (Marca y : marcas) {
                            if (x.getPais().equals(y.getPais())) {
                                contador += y.getCarros().size();
                            }
                        }
                        if (contador > maxP) {
                            maxP = contador;
                            paisMasComun = x.getPais();
                        }
                    }
                    System.out.println("El pais mas comun es: " + paisMasComun + " con " + maxP + " carros.");
                    lanzarMenu();
                    opcion = scint.nextInt();
                    break;


                case 9:
                    if (duenos.isEmpty()) {
                        System.out.println("No hay duenos registrados.");
                        lanzarMenu();
                        opcion = scint.nextInt();
                        break;
                    }
                    for (Dueno x : duenos) {
                        System.out.println("\nDueno: " + x.getNombre() + " " + x.getApellido());
                        if (x.getIncidentes().isEmpty()) {
                            System.out.println("  Sin incidentes registrados.");
                        } else {
                            for (Incidente y : x.getIncidentes()) {
                                System.out.println("  - " + y);
                            }
                        }

                    }
                    lanzarMenu();
                    opcion = scint.nextInt();
                    break;


                case 10:
                    salir = true;
                    System.out.println("Hasta luego");
                    System.exit(0);


                default:
                    System.out.println("Opcion no valida");
                    lanzarMenu();
                    opcion = scint.nextInt();
                    break;

            }
        }
    }
}


